<?php

namespace App\Livewire\Panel\Layouts;

use Livewire\Component;

class Toggle extends Component
{
    public function render()
    {
        return view('livewire.panel.layouts.toggle');
    }
}
