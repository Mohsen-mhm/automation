<?php

namespace App\Livewire\Panel\Configs;

use App\Models\Config;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Gate;
use Livewire\Attributes\Validate;
use Livewire\Component;

class EditConfig extends Component
{
    public bool $isJsonType = false;
    public $config;

    #[Validate('required|string|min:2')]
    public string $title;
    #[Validate('required')]
    public string|Collection $value;
    #[Validate('nullable|integer')]
    public int|null $cost;
    public $valueInput;
    protected $listeners = [
        'editInitialize' => 'initialization',
        'refresh' => '$refresh'
    ];

    public function initialization($id): void
    {
        $this->reset();
        $this->config = Config::query()->find($id);
        $this->title = collect($this->config)->get('title');
        $this->value = collect($this->config)->get('type') == Config::STRING_TYPE ? collect($this->config)->get('value') : collect(json_decode(collect($this->config)->get('value')));
        $this->cost = collect($this->config)->get('cost');

        $this->isJsonType = collect($this->config)->get('type') == \App\Models\Config::JSON_TYPE;
    }

    public function addJsonValue(): void
    {
        $this->value = $this->value->push($this->valueInput);
        $this->dispatch('refresh');
        $this->reset('valueInput');
    }

    public function removeJsonValue($item): void
    {
        $this->value->forget($this->value->search($item));
        $this->dispatch('refresh');
        $this->reset('valueInput');
    }

    public function mount()
    {
        abort_if(!Gate::allows(Config::CONFIG_EDIT), 403);
    }

    public function update()
    {
        $validData = $this->validate();

        $this->config->update($validData);

        $this->dispatch('refresh-table');
        $this->dispatch('close-edit-modal');
        $this->reset();
        toastr()->success('Updated successfully.');
    }

    public function render()
    {
        return view('livewire.panel.configs.edit-config');
    }
}
