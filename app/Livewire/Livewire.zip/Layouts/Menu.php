<?php

namespace App\Livewire\Layouts;

use Livewire\Component;

class Menu extends Component
{
    public function render()
    {
        return view('livewire.layouts.menu');
    }
}
